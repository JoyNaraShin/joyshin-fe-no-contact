/** 연락처 제외판에서도 유지하는 프로젝트 링크. */
export const LINKS = [
  {
    href: "https://joyshin-proto-lab.vercel.app/",
    label: "프로토타입 모음",
    desc: "AI 워크플로로 만든 웹앱 프로토타입 모음",
  },
] as const;
